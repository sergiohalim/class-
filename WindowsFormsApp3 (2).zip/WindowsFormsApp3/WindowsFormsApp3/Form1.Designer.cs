﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBox_name = new System.Windows.Forms.TextBox();
            this.txtBox_teamnumber = new System.Windows.Forms.TextBox();
            this.txtBox_position = new System.Windows.Forms.TextBox();
            this.cmb_nationality = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBox_height = new System.Windows.Forms.TextBox();
            this.txtBox_weight = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.cmb_teamname = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_playertoteam = new System.Windows.Forms.Button();
            this.txtBox_playerid = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmb_team = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.btn_update = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Team_Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Position";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Nationality";
            // 
            // txtBox_name
            // 
            this.txtBox_name.Location = new System.Drawing.Point(136, 27);
            this.txtBox_name.Name = "txtBox_name";
            this.txtBox_name.Size = new System.Drawing.Size(100, 20);
            this.txtBox_name.TabIndex = 4;
            // 
            // txtBox_teamnumber
            // 
            this.txtBox_teamnumber.Location = new System.Drawing.Point(136, 54);
            this.txtBox_teamnumber.Name = "txtBox_teamnumber";
            this.txtBox_teamnumber.Size = new System.Drawing.Size(100, 20);
            this.txtBox_teamnumber.TabIndex = 5;
            // 
            // txtBox_position
            // 
            this.txtBox_position.Location = new System.Drawing.Point(136, 125);
            this.txtBox_position.Name = "txtBox_position";
            this.txtBox_position.Size = new System.Drawing.Size(100, 20);
            this.txtBox_position.TabIndex = 6;
            // 
            // cmb_nationality
            // 
            this.cmb_nationality.FormattingEnabled = true;
            this.cmb_nationality.Location = new System.Drawing.Point(136, 91);
            this.cmb_nationality.Name = "cmb_nationality";
            this.cmb_nationality.Size = new System.Drawing.Size(121, 21);
            this.cmb_nationality.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Height";
            // 
            // txtBox_height
            // 
            this.txtBox_height.Location = new System.Drawing.Point(136, 152);
            this.txtBox_height.Name = "txtBox_height";
            this.txtBox_height.Size = new System.Drawing.Size(100, 20);
            this.txtBox_height.TabIndex = 9;
            // 
            // txtBox_weight
            // 
            this.txtBox_weight.Location = new System.Drawing.Point(136, 190);
            this.txtBox_weight.Name = "txtBox_weight";
            this.txtBox_weight.Size = new System.Drawing.Size(100, 20);
            this.txtBox_weight.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Weight";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(136, 237);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "BirthDate";
            // 
            // cmb_teamname
            // 
            this.cmb_teamname.FormattingEnabled = true;
            this.cmb_teamname.Location = new System.Drawing.Point(136, 278);
            this.cmb_teamname.Name = "cmb_teamname";
            this.cmb_teamname.Size = new System.Drawing.Size(121, 21);
            this.cmb_teamname.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 278);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Team Name";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(205, 305);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 16;
            // 
            // btn_playertoteam
            // 
            this.btn_playertoteam.Location = new System.Drawing.Point(51, 305);
            this.btn_playertoteam.Name = "btn_playertoteam";
            this.btn_playertoteam.Size = new System.Drawing.Size(118, 23);
            this.btn_playertoteam.TabIndex = 17;
            this.btn_playertoteam.Text = "Add Player To Team";
            this.btn_playertoteam.UseVisualStyleBackColor = true;
            this.btn_playertoteam.Click += new System.EventHandler(this.btn_playertoteam_Click);
            // 
            // txtBox_playerid
            // 
            this.txtBox_playerid.Location = new System.Drawing.Point(136, 1);
            this.txtBox_playerid.Name = "txtBox_playerid";
            this.txtBox_playerid.Size = new System.Drawing.Size(100, 20);
            this.txtBox_playerid.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(48, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Player ID";
            // 
            // cmb_team
            // 
            this.cmb_team.FormattingEnabled = true;
            this.cmb_team.Location = new System.Drawing.Point(429, 12);
            this.cmb_team.Name = "cmb_team";
            this.cmb_team.Size = new System.Drawing.Size(121, 21);
            this.cmb_team.TabIndex = 21;
            this.cmb_team.SelectedIndexChanged += new System.EventHandler(this.cmb_team_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(341, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Team";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(329, 46);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(459, 58);
            this.dataGridView2.TabIndex = 22;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(329, 114);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(459, 117);
            this.dataGridView3.TabIndex = 23;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(457, 243);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(118, 23);
            this.btn_update.TabIndex = 24;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.cmb_team);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtBox_playerid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btn_playertoteam);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmb_teamname);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtBox_weight);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtBox_height);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmb_nationality);
            this.Controls.Add(this.txtBox_position);
            this.Controls.Add(this.txtBox_teamnumber);
            this.Controls.Add(this.txtBox_name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Nationality";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBox_name;
        private System.Windows.Forms.TextBox txtBox_teamnumber;
        private System.Windows.Forms.TextBox txtBox_position;
        private System.Windows.Forms.ComboBox cmb_nationality;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBox_height;
        private System.Windows.Forms.TextBox txtBox_weight;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmb_teamname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_playertoteam;
        private System.Windows.Forms.TextBox txtBox_playerid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmb_team;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button btn_update;
    }
}

